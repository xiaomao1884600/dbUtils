CREATE TRIGGER `enrollment_update_log_update`
AFTER UPDATE ON `t_enrollment`
FOR EACH ROW
  BEGIN
INSERT INTO t_enrollmentupdatelog(enrollmentid, type) values(new.enrollmentid, 'u');
END