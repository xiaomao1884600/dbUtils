CREATE TRIGGER `enrollment_update_log_insert`
AFTER INSERT ON `t_enrollment`
FOR EACH ROW
  BEGIN
INSERT INTO t_enrollmentupdatelog(enrollmentid, type) values(new.enrollmentid, 'i');
END